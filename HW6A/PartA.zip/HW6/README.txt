/*
Homework 6, 600.120 Spring 2015

Tanay Agarwal
tagarwa2@jhu.edu
tagarwa2
04/10/2015
443-691-8192
*/

To run tests, type "make test".

Provided is FileDir.h, FileDir.cpp, and FileDirTest.cpp.
The header file contains the declarations and information about the class,
while FileDir.cpp contains all the actual definitions and function code.
If the tests run and finish successfully, then the header and .cpp FileDir files
work as required.